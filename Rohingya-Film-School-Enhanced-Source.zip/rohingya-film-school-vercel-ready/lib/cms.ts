import { createHmac, timingSafeEqual } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';

type ItemType = 'news' | 'team' | 'photo' | 'film';
const types = new Set<ItemType>(['news', 'team', 'photo', 'film']);

export interface StoredRecord {
  id: string;
  type: ItemType;
  data: string;
  published: number;
  version: number;
  created_at: string;
  updated_at: string;
  updated_by: string;
  deleted_at: string | null;
}

export const SESSION_COOKIE = '__rfs_session';

function getSecret(): string {
  return process.env.ADMIN_SECRET || process.env.AUTH_SECRET || 'rfs-vercel-default-session-secret-2026';
}

export function createSessionCookieValue(email: string): string {
  const cleanEmail = email.trim().toLowerCase();
  const payload = Buffer.from(JSON.stringify({ id: `user_${cleanEmail}`, email: cleanEmail, iat: Date.now() })).toString('base64url');
  const sig = createHmac('sha256', getSecret()).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

export function verifySessionCookieValue(token: string): { id: string; email: string } | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [payload, sig] = parts;
  const expected = createHmac('sha256', getSecret()).update(payload).digest('base64url');
  try {
    const a = Buffer.from(sig);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf-8'));
    if (!data?.email || !data?.id) return null;
    return { id: String(data.id), email: String(data.email).trim().toLowerCase() };
  } catch {
    return null;
  }
}

function parseCookieHeader(header: string | null, name: string): string | null {
  if (!header) return null;
  for (const part of header.split(';')) {
    const trimmed = part.trim();
    if (trimmed.startsWith(`${name}=`)) {
      return decodeURIComponent(trimmed.slice(name.length + 1));
    }
  }
  return null;
}

const json = (data: unknown, status = 200) =>
  Response.json(data, {
    status,
    headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' },
  });

export function getAllowedAdminEmails(): string[] {
  const envList = (process.env.ADMIN_EMAILS || 'faruquebrr@gmail.com,mohammedzonaid7@gmail.com')
    .split(',')
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
  return envList.length ? envList : ['faruquebrr@gmail.com'];
}

export function identity(request: Request) {
  let id = request.headers.get('oai-authenticated-user-id');
  let email = request.headers.get('oai-authenticated-user-email')?.trim().toLowerCase();

  if (!id || !email) {
    const cookieToken = parseCookieHeader(request.headers.get('cookie'), SESSION_COOKIE);
    if (cookieToken) {
      const verified = verifySessionCookieValue(cookieToken);
      if (verified) {
        id = verified.id;
        email = verified.email;
      }
    }
  }

  if (!id || !email) return null;
  const allowed = getAllowedAdminEmails();
  return { id, email, canEdit: allowed.includes(email) };
}

function getStoreFilePath(): string {
  if (process.env.CMS_DATA_FILE) return process.env.CMS_DATA_FILE;
  if (process.env.VERCEL) return '/tmp/rfs-cms-store.json';
  return join(process.cwd(), 'content', 'cms-data.json');
}

function getMediaDirPath(): string {
  if (process.env.CMS_MEDIA_DIR) return process.env.CMS_MEDIA_DIR;
  if (process.env.VERCEL) return '/tmp/rfs-cms-media';
  return join(process.cwd(), 'content', 'cms-media');
}

async function readStore(): Promise<StoredRecord[]> {
  const filePath = getStoreFilePath();
  try {
    const raw = await readFile(/*turbopackIgnore: true*/ filePath, 'utf-8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    try {
      const seedPath = join(process.cwd(), 'content', 'cms-data.json');
      if (seedPath !== filePath) {
        const seedRaw = await readFile(seedPath, 'utf-8');
        const parsed = JSON.parse(seedRaw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // ignore
    }
    return [];
  }
}

async function writeStore(records: StoredRecord[]): Promise<void> {
  const filePath = getStoreFilePath();
  await mkdir(/*turbopackIgnore: true*/ dirname(/*turbopackIgnore: true*/ filePath), { recursive: true });
  await writeFile(/*turbopackIgnore: true*/ filePath, JSON.stringify(records, null, 2), 'utf-8');
}

function fail(message: string, status = 400): never {
  throw Object.assign(new Error(message), { status });
}

function text(value: unknown, label: string, max: number, required = false) {
  if (typeof value !== 'string') {
    if (required) fail(`${label} is required.`);
    return '';
  }
  const s = value.trim();
  if (required && !s) fail(`${label} is required.`);
  if (s.length > max) fail(`${label} is too long (maximum ${max} characters).`);
  return s;
}

function url(value: unknown, label: string, required = false) {
  const s = text(value, label, 2000, required);
  if (!s) return '';
  try {
    const u = new URL(s);
    if (!['http:', 'https:'].includes(u.protocol) || u.username || u.password)
      fail(`${label} must be a web link.`);
    return u.href;
  } catch {
    fail(`${label} must start with https:// or http://.`);
  }
}

function image(value: unknown) {
  const s = text(value, 'Image', 500);
  if (
    s &&
    !/^\/(?:assets\/[a-zA-Z0-9_.-]+|media\/[a-f0-9-]{36}\.(?:jpg|png|webp|gif))$/.test(s)
  )
    fail('Choose an uploaded image.');
  return s;
}

function validate(type: ItemType, raw: Record<string, unknown>) {
  const common = {
    image: image(raw.image),
    alt: text(raw.alt, 'Image description', 500),
    credit: text(raw.credit, 'Photographer credit', 250),
    order: Number.isInteger(Number(raw.order))
      ? Math.max(0, Math.min(9999, Number(raw.order)))
      : 0,
  };
  if (common.image && !common.alt) fail('Add an image description for accessibility.');
  if (type === 'news') {
    const date = text(raw.date, 'Date', 10, true);
    if (
      !/^\d{4}-\d{2}-\d{2}$/.test(date) ||
      !Number.isFinite(Date.parse(date)) ||
      new Date(date).toISOString().slice(0, 10) !== date
    )
      fail('Choose a valid publication date.');
    return {
      ...common,
      title: text(raw.title, 'Title', 200, true),
      date,
      summary: text(raw.summary, 'Summary', 600, true),
      body: text(raw.body, 'Article', 40000, true),
      link: url(raw.link, 'Related link'),
    };
  }
  if (type === 'team')
    return {
      ...common,
      name: text(raw.name, 'Name', 150, true),
      role: text(raw.role, 'Role', 180, true),
      bio: text(raw.bio, 'Biography', 5000, true),
      link: url(raw.link, 'Portfolio link'),
    };
  if (type === 'photo') {
    if (!common.image) fail('Upload a photograph.');
    const category = text(raw.category, 'Category', 30, true);
    if (!['filmmaking', 'training', 'community'].includes(category))
      fail('Choose a photo category.');
    if (!common.credit) fail('Add a photographer credit (or the school archive).');
    return {
      ...common,
      title: text(raw.title, 'Title', 180, true),
      caption: text(raw.caption, 'Caption', 1200, true),
      category,
    };
  }
  return {
    ...common,
    title: text(raw.title, 'Title', 200, true),
    description: text(raw.description, 'Description', 5000, true),
    video: url(raw.video, 'Film link', true),
    year: text(raw.year, 'Year', 4),
    language: text(raw.language, 'Language', 100),
  };
}

function record(row: StoredRecord) {
  return {
    id: row.id,
    type: row.type,
    data: JSON.parse(row.data),
    published: Boolean(row.published),
    version: row.version,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    archived: Boolean(row.deleted_at),
  };
}

async function readJSON(request: Request) {
  if (!request.headers.get('content-type')?.includes('application/json'))
    fail('Expected JSON.', 415);
  const body = await request.text();
  if (body.length > 80000) fail('This entry is too large.', 413);
  try {
    const v = JSON.parse(body);
    if (!v || typeof v !== 'object' || Array.isArray(v)) fail('Invalid content.');
    return v;
  } catch {
    fail('Invalid JSON.');
  }
}

export async function publicContent() {
  try {
    const rows = await readStore();
    const publishedRows = rows
      .filter((r) => r.published === 1 && !r.deleted_at)
      .sort((a, b) => b.updated_at.localeCompare(a.updated_at))
      .slice(0, 500);
    return json({ items: publishedRows.map(record) });
  } catch (e) {
    console.error('Content read failed', e instanceof Error ? e.message : 'Unknown error');
    return json({ items: [] }, 200);
  }
}

export async function cms(request: Request, parts: string[]) {
  try {
    const user = identity(request);
    if (!user)
      return json(
        {
          error: 'Sign in with your authorized account.',
          signIn: '/signin-with-chatgpt?return_to=%2Fadmin',
        },
        401
      );
    if (!user.canEdit)
      return json(
        {
          error:
            'This account has viewing access only. Sign in with the account authorized to manage this website.',
        },
        403
      );
    const method = request.method;
    if (!['GET', 'HEAD'].includes(method)) {
      const origin = request.headers.get('origin');
      if (origin !== new URL(request.url).origin || request.headers.get('x-rfs-action') !== 'edit')
        return json({ error: 'This request did not come from the content dashboard.' }, 403);
    }
    if (parts[0] === 'session' && method === 'GET')
      return json({ email: user.email, canEdit: true });

    if (parts[0] === 'upload' && method === 'POST') {
      const declared = Number(request.headers.get('content-length') || 0);
      if (declared > 10 * 1024 * 1024)
        fail('Please choose an image smaller than 10 MB.', 413);
      const reader = request.body?.getReader();
      if (!reader) fail('Choose an image.');
      const chunks: Uint8Array[] = [];
      let size = 0;
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > 10 * 1024 * 1024) {
          await reader.cancel();
          fail('Please choose an image smaller than 10 MB.', 413);
        }
        chunks.push(value);
      }
      const bytes = new Uint8Array(size);
      let pos = 0;
      for (const chunk of chunks) {
        bytes.set(chunk, pos);
        pos += chunk.length;
      }
      let extension = '',
        mime = '';
      const head = String.fromCharCode(...bytes.slice(0, 12));
      if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
        extension = 'jpg';
        mime = 'image/jpeg';
      } else if (bytes.slice(0, 8).join(',') === '137,80,78,71,13,10,26,10') {
        extension = 'png';
        mime = 'image/png';
      } else if (head.startsWith('RIFF') && head.slice(8, 12) === 'WEBP') {
        extension = 'webp';
        mime = 'image/webp';
      } else if (head.startsWith('GIF87a') || head.startsWith('GIF89a')) {
        extension = 'gif';
        mime = 'image/gif';
      } else fail('Use a JPG, PNG, WebP, or GIF image.');
      const key = `${crypto.randomUUID()}.${extension}`;
      const mediaDir = getMediaDirPath();
      const targetFile = join(/*turbopackIgnore: true*/ mediaDir, key);
      const metaFile = join(/*turbopackIgnore: true*/ mediaDir, `${key}.meta.json`);
      await mkdir(/*turbopackIgnore: true*/ mediaDir, { recursive: true });
      await writeFile(/*turbopackIgnore: true*/ targetFile, bytes);
      await writeFile(
        /*turbopackIgnore: true*/ metaFile,
        JSON.stringify({ contentType: mime, uploadedBy: user.id }),
        'utf-8'
      );
      return json({ url: `/media/${key}` }, 201);
    }

    if (parts[0] !== 'items') return json({ error: 'Not found.' }, 404);
    const rows = await readStore();

    if (parts.length === 1 && method === 'GET') {
      const sorted = [...rows]
        .sort((a, b) => b.updated_at.localeCompare(a.updated_at))
        .slice(0, 1000);
      return json({ items: sorted.map(record) });
    }
    if (parts.length === 1 && method === 'POST') {
      const input = await readJSON(request);
      if (!types.has(input.type as ItemType)) fail('Choose a content type.');
      const itemType = input.type as ItemType;
      const data = validate(itemType, input.data || {});
      const id = crypto.randomUUID(),
        now = new Date().toISOString();
      const newRow: StoredRecord = {
        id,
        type: itemType,
        data: JSON.stringify(data),
        published: input.published === true ? 1 : 0,
        version: 1,
        created_at: now,
        updated_at: now,
        updated_by: user.id,
        deleted_at: null,
      };
      rows.unshift(newRow);
      await writeStore(rows);
      return json(
        {
          item: {
            id,
            type: itemType,
            data,
            published: input.published === true,
            version: 1,
            createdAt: now,
            updatedAt: now,
            archived: false,
          },
        },
        201
      );
    }
    const id = parts[1];
    if (!/^[a-f0-9-]{36}$/.test(id || '')) return json({ error: 'Not found.' }, 404);
    const index = rows.findIndex((r) => r.id === id);
    if (index === -1) return json({ error: 'This entry no longer exists.' }, 404);
    const previous = rows[index];
    if (method !== 'PUT') return json({ error: 'Method not allowed.' }, 405);
    const input = await readJSON(request);
    if (input.version !== previous.version)
      return json(
        { error: 'Someone updated this entry. Reload the dashboard before editing it again.' },
        409
      );
    const data = input.data ? validate(previous.type, input.data) : JSON.parse(previous.data);
    const published =
      typeof input.published === 'boolean' ? input.published : Boolean(previous.published);
    const deletedAt =
      typeof input.archived === 'boolean'
        ? input.archived
          ? new Date().toISOString()
          : null
        : previous.deleted_at;
    const now = new Date().toISOString();
    const updatedRow: StoredRecord = {
      ...previous,
      data: JSON.stringify(data),
      published: published ? 1 : 0,
      deleted_at: deletedAt,
      version: previous.version + 1,
      updated_at: now,
      updated_by: user.id,
    };
    rows[index] = updatedRow;
    await writeStore(rows);
    return json({
      item: {
        ...record(previous),
        data,
        published,
        archived: Boolean(deletedAt),
        version: previous.version + 1,
        updatedAt: now,
      },
    });
  } catch (e: any) {
    if (e.status) return json({ error: e.message }, e.status);
    console.error('Dashboard request failed', e instanceof Error ? e.message : 'Unknown error');
    return json({ error: 'Your update could not be saved. Please try again.' }, 500);
  }
}

export async function media(key: string) {
  if (!/^[a-f0-9-]{36}\.(jpg|png|webp|gif)$/.test(key))
    return new Response('Not found', { status: 404 });
  const mediaDir = getMediaDirPath();
  try {
    const filePath = join(/*turbopackIgnore: true*/ mediaDir, key);
    const bytes = await readFile(/*turbopackIgnore: true*/ filePath);
    let contentType = 'application/octet-stream';
    if (key.endsWith('.jpg')) contentType = 'image/jpeg';
    else if (key.endsWith('.png')) contentType = 'image/png';
    else if (key.endsWith('.webp')) contentType = 'image/webp';
    else if (key.endsWith('.gif')) contentType = 'image/gif';

    const headers = new Headers();
    headers.set('Content-Type', contentType);
    headers.set('Cache-Control', 'private, max-age=3600');
    headers.set('X-Content-Type-Options', 'nosniff');
    headers.set('Content-Security-Policy', "default-src 'none'; sandbox");
    return new Response(bytes, { headers });
  } catch {
    return new Response('Not found', { status: 404 });
  }
}
