(() => {
  const el=(tag,cls,value)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(value!==undefined)n.textContent=value;return n;};
  const image=(data,cls)=>{if(!data.image)return null;const n=el('img',cls);n.src=data.image;n.alt=data.alt||'';n.loading='lazy';return n;};
  const link=(url,label,cls)=>{const n=el('a',cls,label);n.href=url;n.target='_blank';n.rel='noopener noreferrer';return n;};
  let newsDialog;
  function openNews(item,trigger){
    if(!newsDialog){newsDialog=el('dialog','news-dialog');newsDialog.setAttribute('aria-labelledby','news-dialog-title');document.body.append(newsDialog);newsDialog.addEventListener('close',()=>{document.body.classList.remove('modal-open');newsDialog._trigger?.focus();});}
    newsDialog.replaceChildren();newsDialog._trigger=trigger;
    const head=el('div','dialog-header');const label=el('h2','', 'News from the school');const close=el('button','dialog-close','Close ×');close.setAttribute('aria-label','Close article');close.addEventListener('click',()=>newsDialog.close());head.append(label,close);newsDialog.append(head);
    const d=item.data,img=image(d,'news-hero');if(img)newsDialog.append(img);
    const article=el('article','news-article');article.append(el('p','eyebrow red-text',new Date(d.date+'T12:00:00').toLocaleDateString(undefined,{year:'numeric',month:'long',day:'numeric'})));
    const title=el('h2','',d.title);title.id='news-dialog-title';article.append(title);
    if(img&&d.credit)article.append(el('p','news-credit','Photograph: '+d.credit));
    d.body.split(/\n\s*\n/).filter(Boolean).forEach(p=>article.append(el('p','news-paragraph',p)));
    if(d.link)article.append(link(d.link,'Related story ↗','text-link'));newsDialog.append(article);document.body.classList.add('modal-open');newsDialog.showModal();close.focus();
  }
  async function load(){
    try {
      const response=await fetch('/api/content',{credentials:'same-origin',cache:'no-store',signal:AbortSignal.timeout(12000)});if(!response.ok)return;
      const {items}=await response.json();if(!Array.isArray(items))return;
      const of=type=>items.filter(i=>i.type===type).sort((a,b)=>(Number(a.data.order)||0)-(Number(b.data.order)||0));
      const news=of('news').sort((a,b)=>b.data.date.localeCompare(a.data.date));
      document.querySelectorAll('[href="#news"]').forEach(a=>a.hidden=!news.length);
      const newsSection=document.querySelector('#news');newsSection.hidden=!news.length;
      news.forEach(item=>{const d=item.data,card=el('article','news-card'),img=image(d,'');if(img)card.append(img);const date=el('p','eyebrow red-text',new Date(d.date+'T12:00:00').toLocaleDateString(undefined,{year:'numeric',month:'short',day:'numeric'}));const title=el('h3'),button=el('button','plain-button',d.title);button.addEventListener('click',()=>openNews(item,button));title.append(button);const read=el('button','text-link','Read story ↗');read.addEventListener('click',()=>openNews(item,read));card.append(date,title,el('p','news-summary',d.summary),read);document.querySelector('#news-list').append(card);});
      const team=of('team'),teamList=document.querySelector('#team-list');teamList.hidden=!team.length;
      team.forEach(({data:d})=>{const card=el('article','cms-team-card'),img=image(d,'');if(img)card.append(img);else card.append(el('div','team-monogram',d.name.split(/\s+/).slice(0,2).map(n=>n[0]).join('')));card.append(el('p','eyebrow red-text',d.role),el('h3','',d.name),el('p','',d.bio));if(d.link)card.append(link(d.link,'Portfolio ↗','text-link'));if(d.credit&&img)card.append(el('small','','Photograph: '+d.credit));teamList.append(card);});
      const gallery=document.querySelector('.photo-grid');
      of('photo').forEach(({data:d})=>{const button=el('button','photo-item');button.type='button';button.dataset.category=d.category;button.dataset.src=d.image;button.dataset.caption=d.caption+(d.credit?' — Photograph: '+d.credit:'');const img=image(d,'');if(!img)return;const copy=el('span'),category={filmmaking:'BEHIND THE LENS',training:'LEARNING TOGETHER',community:'OUR COMMUNITY'}[d.category];const arrow=el('i','','↗');arrow.setAttribute('aria-hidden','true');copy.append(el('small','',category),el('strong','',d.title),arrow);button.append(img,copy);gallery.append(button);});
      const count=gallery.querySelectorAll('.photo-item').length;const all=document.querySelector('[data-filter="all"] span');all.textContent=String(count).padStart(2,'0');document.querySelector('.gallery-count').textContent=count+' photographs';
      const films=of('film'),filmList=document.querySelector('#more-films');filmList.hidden=!films.length;
      films.forEach(({data:d})=>{const card=el('article','cms-film-card'),img=image(d,'');if(img)card.append(img);card.append(el('p','eyebrow',[d.year,d.language].filter(Boolean).join(' · ')),el('h3','',d.title),el('p','',d.description),link(d.video,'Watch film ↗','text-link light'));if(d.credit&&img)card.append(el('small','','Image: '+d.credit));filmList.append(card);});
    }catch(error){console.warn('School updates are temporarily unavailable. The archive remains available.');}
  }
  load();
})();
