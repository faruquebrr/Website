(() => {
  // 1. Resource Archive Filtering, Search & Reset
  const cards = [...document.querySelectorAll('.resource-card')];
  const buttons = [...document.querySelectorAll('[data-resource-filter]')];
  const searchInput = document.querySelector('#resource-search');
  const resetBtn = document.querySelector('#resource-reset');
  let category = 'all';

  function filterResources() {
    if (!searchInput) return;
    const term = searchInput.value.trim().toLowerCase();
    let count = 0;
    cards.forEach(card => {
      const match =
        (category === 'all' || card.dataset.resourceCategory === category) &&
        card.textContent.toLowerCase().includes(term);
      card.hidden = !match;
      if (match) count++;
    });
    const countEl = document.querySelector('#resource-count');
    if (countEl) countEl.textContent = `${count} resource${count === 1 ? '' : 's'}`;
    const emptyEl = document.querySelector('#resource-empty');
    if (emptyEl) emptyEl.hidden = count > 0;
  }

  buttons.forEach(button =>
    button.addEventListener('click', () => {
      category = button.dataset.resourceFilter;
      buttons.forEach(b => b.setAttribute('aria-pressed', String(b === button)));
      filterResources();
    })
  );
  if (searchInput) searchInput.addEventListener('input', filterResources);
  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      category = 'all';
      if (searchInput) searchInput.value = '';
      buttons.forEach(b => b.setAttribute('aria-pressed', String(b.dataset.resourceFilter === 'all')));
      filterResources();
    });
  }
  filterResources();

  // 2. Interactive Full Biography Modal
  const bioDialog = document.querySelector('#bio-dialog');
  const bioDialogBody = document.querySelector('#bio-dialog-body');
  const bioDialogClose = document.querySelector('#bio-dialog-close');
  let lastBioTrigger = null;

  document.querySelectorAll('[data-bio-target]').forEach(btn => {
    btn.addEventListener('click', () => {
      const templateId = btn.getAttribute('data-bio-target');
      const tpl = document.getElementById(templateId);
      if (!tpl || !bioDialog || !bioDialogBody) return;
      lastBioTrigger = btn;
      bioDialogBody.replaceChildren(tpl.content.cloneNode(true));
      document.body.classList.add('modal-open');
      bioDialog.showModal();
      bioDialogClose?.focus();
    });
  });

  if (bioDialogClose && bioDialog) {
    bioDialogClose.addEventListener('click', () => bioDialog.close());
    bioDialog.addEventListener('click', event => {
      if (event.target === bioDialog) {
        const rect = bioDialog.getBoundingClientRect();
        if (
          event.clientX < rect.left ||
          event.clientX > rect.right ||
          event.clientY < rect.top ||
          event.clientY > rect.bottom
        ) {
          bioDialog.close();
        }
      }
    });
    bioDialog.addEventListener('close', () => {
      document.body.classList.remove('modal-open');
      bioDialogBody.replaceChildren();
      lastBioTrigger?.focus();
    });
  }

  // 3. Service & Training Pre-fill into Contact Form
  const interestSelect = document.querySelector('#contact-interest');
  const messageInput = document.querySelector('#contact-message');
  document.querySelectorAll('[data-interest]').forEach(link => {
    link.addEventListener('click', () => {
      const interest = link.getAttribute('data-interest');
      const service = link.getAttribute('data-service');
      if (interestSelect && interest) {
        interestSelect.value = interest;
      }
      if (messageInput && service && !messageInput.value.trim()) {
        messageInput.value = `Hello Rohingya Film School team,\n\nI would like to inquire about ${service}.\n\n`;
      }
    });
  });

  // 4. One-Click Copy Email Button
  const copyEmailBtn = document.querySelector('#copy-email');
  if (copyEmailBtn && navigator.clipboard) {
    copyEmailBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText('contact@rohingyafilmschool.org');
        const original = copyEmailBtn.textContent;
        copyEmailBtn.textContent = 'Copied ✓';
        setTimeout(() => {
          copyEmailBtn.textContent = original;
        }, 2500);
      } catch {
        // Fallback ignored
      }
    });
  }
})();
