const q = s => document.querySelector(s);
const types = {
  news: { label:'News & updates', singular:'news', description:'Share stories, activities, and announcements from the school.', fields:[['title','Title','text',200,true],['date','Publication date','date',10,true],['summary','Short summary','textarea',600,true],['body','Full article','long',40000,true],['link','Related link (optional)','url',2000,false]] },
  team: { label:'Team members', singular:'team member', description:'Introduce the people behind the stories.', fields:[['name','Full name','text',150,true],['role','Role or position','text',180,true],['bio','Biography','long',5000,true],['link','Portfolio or website (optional)','url',2000,false]] },
  photo: { label:'Photo gallery', singular:'photograph', description:'Add photographs, captions, and the people who made them.', fields:[['title','Title','text',180,true],['caption','Caption','textarea',1200,true],['category','Category','select',30,true]] },
  film: { label:'Films & videos', singular:'film', description:'Share your films and videos with a link to watch.', fields:[['title','Film title','text',200,true],['video','YouTube, Vimeo, or other film link','url',2000,true],['description','Description','long',5000,true],['year','Year','text',4,false],['language','Language','text',100,false]] }
};
let items = [], currentType = 'news', currentStatus = 'active', currentItem = null, imageUrl = '', ready = false, saving = false, uploading = false, dirty = false;
const editor = q('#editor'), form = q('#editor-form');
const el = (tag, cls, value) => { const n = document.createElement(tag); if(cls) n.className=cls; if(value !== undefined) n.textContent=value; return n; };
async function api(path, options={}) {
  const response = await fetch('/api/cms/'+path, { credentials:'same-origin', ...options, headers:{'X-RFS-Action':'edit',...(options.body && typeof options.body==='string'?{'Content-Type':'application/json'}:{}),...options.headers} });
  let data; try { data=await response.json(); } catch { throw new Error('The server could not respond. Please try again.'); }
  if(!response.ok) throw new Error(data.error || 'Your request could not be completed.');
  return data;
}
function feedback(message, error=false) { q('#feedback').textContent=message; q('#feedback').className=error?'error':message?'success':''; }
function title(item) { return item.data.title || item.data.name; }
function render() {
  const info=types[currentType]; q('#section-title').textContent=info.label; q('#section-description').textContent=info.description; q('#new-item').textContent='+ Add '+info.singular;
  document.querySelectorAll('[data-type]').forEach(b=>{ if(b.dataset.type===currentType)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current'); });
  document.querySelectorAll('[data-status]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.status===currentStatus)));
  for(const type of Object.keys(types)) q('#count-'+type).textContent=items.filter(i=>i.type===type&&!i.archived).length;
  const mine=items.filter(i=>i.type===currentType);
  q('#stat-published').textContent=mine.filter(i=>i.published&&!i.archived).length;
  q('#stat-drafts').textContent=mine.filter(i=>!i.published&&!i.archived).length;
  q('#stat-archived').textContent=mine.filter(i=>i.archived).length;
  const search=q('#search').value.toLowerCase();
  const visible=mine.filter(i=>(currentStatus==='archived'?i.archived:!i.archived)&&(currentStatus!=='published'||i.published)&&(currentStatus!=='draft'||!i.published)&&[title(i),i.data.role,i.data.summary,i.data.caption].filter(Boolean).join(' ').toLowerCase().includes(search));
  const list=q('#entries');list.replaceChildren();
  if(!visible.length) { const empty=el('div','empty-state');empty.append(el('span','empty-symbol','＋'),el('h2','',search?'No matching entries':currentStatus==='archived'?'Nothing archived yet':'Your next story starts here.'),el('p','',search?'Try another search.':currentStatus==='archived'?'Entries you archive will appear here.':'Add your first '+info.singular+'. You can save a draft before publishing.'));list.append(empty);return; }
  visible.forEach(item=>{
    const row=el('article','entry');
    if(item.data.image) {const img=el('img','entry-image');img.src=item.data.image;img.alt=item.data.alt||'';row.append(img);} else row.append(el('div','entry-placeholder',currentType==='team'?'◌':currentType==='film'?'▷':'↗'));
    const copy=el('div','entry-copy'),badge=el('span','badge '+(item.archived?'archived':item.published?'published':'draft'),item.archived?'Archived':item.published?'Published':'Draft');
    copy.append(badge,el('h2','',title(item)),el('p','',item.data.role||item.data.summary||item.data.caption||item.data.description||''));
    const date=new Date(item.updatedAt).toLocaleDateString(undefined,{day:'numeric',month:'short',year:'numeric'});copy.append(el('small','','Updated '+date));row.append(copy);
    const actions=el('div','entry-actions');
    function action(label, fn, cls=''){const b=el('button',cls,label);b.type='button';b.addEventListener('click',fn);actions.append(b);}
    if(item.archived) action('Restore',()=>update(item,{archived:false}));
    else { action('Edit',()=>openEditor(item));action(item.published?'Unpublish':'Publish',()=>update(item,{published:!item.published}));action('Archive',()=>{if(confirm('Archive “'+title(item)+'”? It will be hidden from the website. You can restore it later.'))update(item,{archived:true});},'subtle'); }
    row.append(actions);list.append(row);
  });
}
async function refresh() { const data=await api('items');items=data.items;render(); }
async function update(item,change) {try {q('#entries').setAttribute('aria-busy','true');const data=await api('items/'+item.id,{method:'PUT',body:JSON.stringify({version:item.version,...change})});items=items.map(i=>i.id===item.id?data.item:i);render();feedback(change.archived===true?'Entry archived. You can restore it from Archived.':change.archived===false?'Entry restored.':data.item.published?'Published. Refresh the website to see your update.':'Saved as a draft and hidden from the website.');}catch(e){feedback(e.message,true);}finally{q('#entries').removeAttribute('aria-busy');}}
function setImage(value) {imageUrl=value;q('#image-preview').hidden=!value;q('.upload-zone').hidden=Boolean(value);if(value)q('#preview-image').src=value;else q('#preview-image').removeAttribute('src');}
function openEditor(item=null) {
  currentItem=item;form.reset();dirty=false;setImage(item?.data.image||'');q('#editor-error').textContent='';q('#upload-status').textContent='';q('#editor-state').textContent='';
  const info=types[currentType];q('#editor-title').textContent=(item?'Edit ':'Add ')+info.singular;q('#editor-intro').textContent=currentType==='photo'?'Add a photograph with a clear description, caption, and photographer credit.':'Write your entry below. Save it privately as a draft, or publish it to the website.';
  const fields=q('#fields');fields.replaceChildren();
  info.fields.forEach(([name,label,type,max,required])=>{const wrap=el('label','',label+(required?' *':''));let input;if(type==='select'){input=el('select');[['filmmaking','Behind the lens'],['training','Learning together'],['community','Our community']].forEach(([v,t])=>{const opt=el('option','',t);opt.value=v;input.append(opt);});}else{input=el(type==='textarea'||type==='long'?'textarea':'input');if(input.tagName==='INPUT')input.type=type;else input.rows=type==='long'?8:3;input.maxLength=max;}input.name=name;input.required=required;input.value=item?.data[name]||(name==='date'?new Date().toLocaleDateString('en-CA'):name==='category'?'community':'');if(type==='url')input.placeholder='https://';wrap.append(input);fields.append(wrap);});
  ['alt','credit','order'].forEach(name=>{form.elements[name].value=item?.data[name]??(name==='order'?0:'');});
  q('#image-heading').textContent=currentType==='team'?'Portrait':currentType==='photo'?'Photograph *':currentType==='film'?'Film image (optional)':'Cover image (optional)';
  editor.showModal();document.body.classList.add('editing');q('#editor-title').setAttribute('tabindex','-1');q('#editor-title').focus();
}
function closeEditor() {if(saving||uploading)return;if(dirty&&!confirm('Close without saving your changes?'))return;editor.close();}
editor.addEventListener('cancel',event=>{event.preventDefault();closeEditor();});
editor.addEventListener('close',()=>{document.body.classList.remove('editing');dirty=false;});
q('#close-editor').addEventListener('click',closeEditor);q('#cancel-editor').addEventListener('click',closeEditor);
form.addEventListener('input',()=>{dirty=true;});
q('#remove-image').addEventListener('click',()=>{setImage('');q('#image-upload').value='';dirty=true;});
q('#image-upload').addEventListener('change',async event=>{
  const file=event.target.files[0];if(!file)return;
  if(file.size>10*1024*1024){q('#upload-status').textContent='Please choose an image smaller than 10 MB.';return;}
  uploading=true;setBusy();q('#upload-status').textContent='Uploading your photograph…';
  try {const result=await api('upload',{method:'POST',body:file,headers:{'Content-Type':file.type}});setImage(result.url);q('#upload-status').textContent='Photograph uploaded. Add a description and credit below.';dirty=true;}catch(e){q('#upload-status').textContent=e.message;}finally{uploading=false;setBusy();}
});
function setBusy(){form.querySelectorAll('button').forEach(b=>b.disabled=saving||uploading);q('#image-upload').disabled=saving||uploading;}
form.addEventListener('submit',async event=>{
  event.preventDefault();if(saving||uploading)return;
  const data=Object.fromEntries(new FormData(form));data.image=imageUrl;data.order=Number(data.order);const published=event.submitter?.value==='publish';
  saving=true;setBusy();q('#editor-error').textContent='';q('#editor-state').textContent=published?'Publishing…':'Saving your draft…';
  try {const payload={type:currentType,data,published,...(currentItem?{version:currentItem.version}:{})};const result=await api('items'+(currentItem?'/'+currentItem.id:''),{method:currentItem?'PUT':'POST',body:JSON.stringify(payload)});items=currentItem?items.map(i=>i.id===currentItem.id?result.item:i):[result.item,...items];dirty=false;editor.close();currentStatus=published?'published':'draft';render();feedback(published?'Published. Refresh the website to see your update.':'Draft saved. It is visible only in the content studio.');}catch(e){q('#editor-error').textContent=e.message;q('#editor-state').textContent='';}finally{saving=false;setBusy();}
});
document.querySelectorAll('[data-type]').forEach(b=>b.addEventListener('click',()=>{currentType=b.dataset.type;currentStatus='active';q('#search').value='';feedback('');render();}));
document.querySelectorAll('[data-status]').forEach(b=>b.addEventListener('click',()=>{currentStatus=b.dataset.status;render();}));
q('#search').addEventListener('input',render);q('#new-item').addEventListener('click',()=>{if(ready)openEditor();});
window.addEventListener('beforeunload',event=>{if(dirty){event.preventDefault();event.returnValue='';}});
(async()=>{try{const session=await api('session');q('#account').textContent=session.email;await refresh();ready=true;q('#new-item').disabled=false;}catch(e){q('#entries').replaceChildren(el('p','error',e.message));q('#account').textContent='Unable to load the studio';feedback('Refresh this page to try again.',true);}})();
