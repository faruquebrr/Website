const menuButton = document.querySelector('.menu-toggle');
const mobileNav = document.querySelector('#mobile-nav');
function positionMobileMenu() {
  if (menuButton.getAttribute('aria-expanded') === 'true') {
    mobileNav.style.top = `${document.querySelector('.site-header').getBoundingClientRect().bottom}px`;
  }
}
function closeMenu() {
  menuButton.setAttribute('aria-expanded', 'false');
  menuButton.setAttribute('aria-label', 'Open navigation');
  mobileNav.hidden = true;
}
menuButton.addEventListener('click', () => {
  const open = menuButton.getAttribute('aria-expanded') !== 'true';
  menuButton.setAttribute('aria-expanded', String(open));
  menuButton.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
  mobileNav.hidden = !open;
  positionMobileMenu();
});
window.addEventListener('scroll', positionMobileMenu, { passive: true });
window.addEventListener('resize', positionMobileMenu);
mobileNav.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMenu));
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeMenu(); });
window.matchMedia('(min-width: 901px)').addEventListener('change', event => { if (event.matches) closeMenu(); });

const filterButtons = [...document.querySelectorAll('[data-filter]')];
let photos = [...document.querySelectorAll('.photo-item')];
filterButtons.forEach(button => button.addEventListener('click', () => {
  filterButtons.forEach(item => item.setAttribute('aria-pressed', String(item === button)));
  const filter = button.dataset.filter;
  photos = [...document.querySelectorAll('.photo-item')];
  photos.forEach(photo => { photo.hidden = filter !== 'all' && photo.dataset.category !== filter; });
  const count = photos.filter(photo => !photo.hidden).length;
  document.querySelector('.gallery-count').textContent = `${count} photograph${count === 1 ? '' : 's'}`;
}));

const dialog = document.querySelector('#media-dialog');
const dialogTitle = document.querySelector('#dialog-title');
const dialogContent = document.querySelector('#dialog-content');
const dialogCaption = document.querySelector('#dialog-caption');
const photoNavigation = document.querySelector('#photo-navigation');
let activePhotos = [], activeIndex = 0, lastTrigger = null, currentMode = '';
function showDialog(trigger) {
  lastTrigger = trigger;
  document.body.classList.add('modal-open');
  dialog.showModal();
  document.querySelector('.dialog-close').focus();
}
function renderPhoto() {
  const photo = activePhotos[activeIndex];
  const img = document.createElement('img');
  img.src = photo.dataset.src;
  img.alt = photo.querySelector('img').alt;
  img.className = 'dialog-image';
  dialogContent.replaceChildren(img);
  dialogTitle.textContent = 'The school’s visual archive';
  dialogCaption.textContent = photo.dataset.caption;
  document.querySelector('#photo-position').textContent = `${activeIndex + 1} / ${activePhotos.length}`;
  photoNavigation.hidden = false;
}
document.querySelector('.photo-grid').addEventListener('click', event => {
  const photo = event.target.closest('.photo-item');
  if (!photo) return;
  photos = [...document.querySelectorAll('.photo-item')];
  currentMode = 'photo';
  activePhotos = photos.filter(item => !item.hidden);
  activeIndex = activePhotos.indexOf(photo);
  renderPhoto();
  showDialog(photo);
});
function changePhoto(direction) {
  activeIndex = (activeIndex + direction + activePhotos.length) % activePhotos.length;
  renderPhoto();
}
document.querySelector('#previous-photo').addEventListener('click', () => changePhoto(-1));
document.querySelector('#next-photo').addEventListener('click', () => changePhoto(1));
dialog.addEventListener('keydown', event => {
  if (currentMode !== 'photo') return;
  if (event.key === 'ArrowRight') { event.preventDefault(); changePhoto(1); }
  if (event.key === 'ArrowLeft') { event.preventDefault(); changePhoto(-1); }
});
document.querySelectorAll('[data-video]').forEach(button => button.addEventListener('click', () => {
  currentMode = 'video';
  dialogTitle.textContent = 'Covid-19 Awareness Song in Rohingya Language';
  const wrapper = document.createElement('div');
  wrapper.className = 'video-wrapper';
  const frame = document.createElement('iframe');
  frame.src = `https://www.youtube-nocookie.com/embed/${button.dataset.video}?autoplay=1&rel=0`;
  frame.title = 'Covid-19 Awareness Song — Osman Goni and Rohingya Film School';
  frame.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';
  frame.allowFullscreen = true;
  wrapper.append(frame);
  const fallback = document.createElement('a');
  fallback.href = `https://www.youtube.com/watch?v=${button.dataset.video}`;
  fallback.target = '_blank'; fallback.rel = 'noopener noreferrer';
  fallback.className = 'video-fallback'; fallback.textContent = 'Watch directly on YouTube ↗';
  dialogContent.replaceChildren(wrapper, fallback);
  dialogCaption.textContent = 'Osman Goni & Rohingya Film School (formerly Omar’s Film School) · 2020 · Community-awareness film.';
  photoNavigation.hidden = true;
  showDialog(button);
}));
document.querySelector('.dialog-close').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', event => { if (event.target === dialog) { const rect = dialog.getBoundingClientRect(); if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close(); } });
dialog.addEventListener('close', () => {
  document.body.classList.remove('modal-open');
  dialogContent.replaceChildren();
  currentMode = '';
  lastTrigger?.focus();
});

document.querySelector('#contact-form').addEventListener('submit', async event => {
  event.preventDefault();
  const data = new FormData(event.currentTarget);
  const subject = `Rohingya Film School — ${data.get('interest')}`;
  const body = `Hello Rohingya Film School,\n\n${data.get('message')}\n\nName: ${data.get('name')}\nReply to: ${data.get('email')}`;
  const mailUrl = `mailto:contact@rohingyafilmschool.org?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  try {
    if (navigator.clipboard) {
      await navigator.clipboard.writeText(`To: contact@rohingyafilmschool.org\nSubject: ${subject}\n\n${body}`);
    }
  } catch {
    // Ignore clipboard fallback errors
  }
  window.location.href = mailUrl;
  document.querySelector('#form-status').textContent = '✓ Your message has been prepared for contact@rohingyafilmschool.org (and copied to your clipboard as a backup).';
});
document.querySelector('#year').textContent = String(new Date().getFullYear());

if ('IntersectionObserver' in window) {
  const links = [...document.querySelectorAll('.desktop-nav a')];
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) links.forEach(link => link.classList.toggle('active', link.hash === '#' + entry.target.id));
    });
  }, { rootMargin: '-15% 0px -60% 0px', threshold: 0 });
  links.forEach(link => { const section = document.querySelector(link.hash); if (section) observer.observe(section); });
}
