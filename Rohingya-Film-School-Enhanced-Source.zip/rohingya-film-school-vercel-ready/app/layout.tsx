import type { Metadata } from "next";
export const metadata: Metadata = {title:"Rohingya Film School",description:"Our stories. Through our own lens."};
export default function RootLayout({children}:{children:React.ReactNode}) {return <html lang="en"><body>{children}</body></html>;}
