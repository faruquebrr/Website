import { cms } from '../../../../lib/cms';
export const dynamic = 'force-dynamic';
async function handle(request: Request, context: { params: Promise<{ path?: string[] }> }) { return cms(request, (await context.params).path || []); }
export { handle as GET, handle as POST, handle as PUT, handle as DELETE };
