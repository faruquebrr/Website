import { publicContent } from '../../../lib/cms';
export const dynamic = 'force-dynamic';
export const GET = publicContent;
