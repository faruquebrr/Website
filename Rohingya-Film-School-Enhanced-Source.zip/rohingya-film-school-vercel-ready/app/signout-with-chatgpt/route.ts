import { SESSION_COOKIE } from "../../lib/cms";

export const dynamic = "force-dynamic";

function safeReturnTo(raw: string | null): string {
  if (!raw || !raw.startsWith("/") || raw.startsWith("//")) return "/";
  return raw;
}

function handleSignOut(request: Request) {
  const url = new URL(request.url);
  const returnTo = safeReturnTo(url.searchParams.get("return_to"));
  const secure = url.protocol === "https:";
  const headers = new Headers();
  headers.set("Location", new URL(returnTo, request.url).toString());
  headers.set("Cache-Control", "private, no-store");
  headers.set(
    "Set-Cookie",
    `${SESSION_COOKIE}=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax${secure ? "; Secure" : ""}`
  );
  return new Response(null, { status: 302, headers });
}

export async function GET(request: Request) {
  return handleSignOut(request);
}

export async function POST(request: Request) {
  return handleSignOut(request);
}
