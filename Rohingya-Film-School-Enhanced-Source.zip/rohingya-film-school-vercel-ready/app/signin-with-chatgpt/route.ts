import { SESSION_COOKIE, createSessionCookieValue, getAllowedAdminEmails } from "../../lib/cms";

export const dynamic = "force-dynamic";

function safeReturnTo(raw: string | null): string {
  if (!raw || !raw.startsWith("/") || raw.startsWith("//")) return "/admin";
  return raw;
}

function renderSignInHtml(returnTo: string, errorMsg = ""): string {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="robots" content="noindex,nofollow">
  <title>Sign in · Rohingya Film School Content Studio</title>
  <link rel="icon" href="/assets/logo.webp">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Serif+Display:ital@0;1&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/admin.css">
  <link rel="stylesheet" href="/vibrant-admin.css">
</head>
<body>
  <main class="access-message" style="max-width:480px;margin:10vh auto;background:#fffdf6;border:1px solid #d6e0cf;border-radius:14px;padding:36px 32px;box-shadow:0 12px 32px rgba(16,63,64,0.08);">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;">
      <img src="/assets/logo.webp" alt="Rohingya Film School logo" width="44" height="44" style="border-radius:6px;">
      <div>
        <p class="eyebrow" style="margin:0;">ROHINGYA FILM SCHOOL</p>
        <strong style="font-family:var(--serif);font-size:20px;color:#174d43;">Content Studio</strong>
      </div>
    </div>
    <h1 style="font-size:34px;margin:10px 0 12px;color:#174d43;">Sign in to manage content</h1>
    <p style="font-size:13px;color:var(--muted);margin-bottom:22px;">Enter your authorized editor email (such as <strong>faruquebrr@gmail.com</strong>) to access the Content Studio dashboard.</p>
    ${errorMsg ? `<p class="error" style="padding:10px 14px;border-radius:6px;margin-bottom:18px;font-size:12px;">${errorMsg}</p>` : ""}
    <form method="POST" action="/signin-with-chatgpt" style="display:grid;gap:16px;">
      <input type="hidden" name="return_to" value="${returnTo.replace(/"/g, "&quot;")}">
      <label style="display:grid;gap:6px;font-size:12px;font-weight:600;color:#173e3b;">
        Authorized email address *
        <input type="email" name="email" required placeholder="faruquebrr@gmail.com" autocomplete="email" style="width:100%;padding:11px 12px;border:1px solid #c5d7bb;border-radius:6px;background:#fffef9;font-size:14px;">
      </label>
      ${
        process.env.ADMIN_PASSWORD
          ? `<label style="display:grid;gap:6px;font-size:12px;font-weight:600;color:#173e3b;">
        Studio passcode *
        <input type="password" name="password" required placeholder="Enter studio passcode" autocomplete="current-password" style="width:100%;padding:11px 12px;border:1px solid #c5d7bb;border-radius:6px;background:#fffef9;font-size:14px;">
      </label>`
          : ""
      }
      <div style="display:flex;align-items:center;gap:14px;margin-top:6px;">
        <button type="submit" class="button" style="margin:0;width:100%;">Continue to Content Studio ↗</button>
      </div>
    </form>
    <div style="margin-top:22px;padding-top:16px;border-top:1px solid #e2eadb;display:flex;justify-content:space-between;font-size:12px;">
      <a href="/" style="color:#25563f;text-decoration:underline;">← Return to website</a>
    </div>
  </main>
</body>
</html>`;
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const returnTo = safeReturnTo(url.searchParams.get("return_to"));
  return new Response(renderSignInHtml(returnTo), {
    status: 200,
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "no-store",
    },
  });
}

export async function POST(request: Request) {
  const formData = await request.formData();
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const password = String(formData.get("password") || "");
  const returnTo = safeReturnTo(String(formData.get("return_to") || "/admin"));

  if (!email || !email.includes("@")) {
    return new Response(renderSignInHtml(returnTo, "Please enter a valid email address."), {
      status: 400,
      headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" },
    });
  }

  if (process.env.ADMIN_PASSWORD && password !== process.env.ADMIN_PASSWORD) {
    return new Response(renderSignInHtml(returnTo, "Invalid studio passcode. Please try again."), {
      status: 401,
      headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" },
    });
  }

  const allowed = getAllowedAdminEmails();
  if (!allowed.includes(email)) {
    return new Response(
      renderSignInHtml(
        returnTo,
        `The account "${email}" does not have editing permission. Sign in with an authorized editor email (e.g. faruquebrr@gmail.com).`
      ),
      {
        status: 403,
        headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" },
      }
    );
  }

  const cookieVal = createSessionCookieValue(email);
  const secure = new URL(request.url).protocol === "https:";
  const headers = new Headers();
  headers.set("Location", new URL(returnTo, request.url).toString());
  headers.set("Cache-Control", "private, no-store");
  headers.set(
    "Set-Cookie",
    `${SESSION_COOKIE}=${encodeURIComponent(cookieVal)}; Path=/; Max-Age=${60 * 60 * 24 * 7}; HttpOnly; SameSite=Lax${secure ? "; Secure" : ""}`
  );
  return new Response(null, { status: 303, headers });
}
