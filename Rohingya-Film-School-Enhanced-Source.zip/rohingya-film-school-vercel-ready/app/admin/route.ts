import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { identity } from "../../lib/cms";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const user = identity(request);
  if (!user) {
    return Response.redirect(new URL("/signin-with-chatgpt?return_to=%2Fadmin", request.url), 302);
  }
  if (!user.canEdit) {
    return new Response(
      '<!doctype html><html lang="en"><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dashboard access</title><link rel="stylesheet" href="/admin.css"><link rel="stylesheet" href="/vibrant-admin.css"></head><body><main class="access-message"><p class="eyebrow">ROHINGYA FILM SCHOOL</p><h1>Use your editing account.</h1><p>This account can view the website. To manage content, sign in as faruquebrr@gmail.com or the site owner.</p><a class="button" href="/signout-with-chatgpt?return_to=%2Fadmin" target="_top">Switch account ↗</a><a href="/">Return to website</a></main></body></html>',
      {
        status: 403,
        headers: {
          "Content-Type": "text/html; charset=utf-8",
          "Cache-Control": "no-store",
        },
      }
    );
  }
  const html = await readFile(join(process.cwd(), "content", "admin.html"), "utf-8");
  return new Response(html, {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Frame-Options": "SAMEORIGIN",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
