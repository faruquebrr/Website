import { media } from '../../../lib/cms';
export const dynamic = 'force-dynamic';
export async function GET(_request: Request, context: { params: Promise<{key: string}> }) { return media((await context.params).key); }
