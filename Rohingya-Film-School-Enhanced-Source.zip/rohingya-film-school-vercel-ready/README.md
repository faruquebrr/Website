# Rohingya Film School — Vercel Deployment Edition

Official website and Content Studio for **Rohingya Film School (RFS)**, configured and ready for zero-configuration deployment on **Vercel** using Next.js 16 (App Router).

## What Was Configured for Vercel

1. **Standard Next.js App Router Build (`next build`)**:
   - Replaced the Cloudflare Workers / `vinext` / Vite wrapper with native Next.js 16 App Router (`package.json`, `next.config.ts`, `tsconfig.json`, and `vercel.json`).
   - Replaced Vite-specific `?raw` HTML imports in `app/route.ts` and `app/admin/route.ts` with standard Node.js `fs/promises` readers.
2. **Serverless-Ready Content Studio & API (`lib/cms.ts`)**:
   - Removed `cloudflare:workers` D1/R2 runtime dependencies so the app builds and runs natively on Vercel Node.js Serverless Functions.
   - Added `/signin-with-chatgpt` and `/signout-with-chatgpt` routes with HMAC-signed HTTP-only session cookies so authorized editors can sign in directly on Vercel to access `/admin`.
3. **Updated Content & Visual Theme**:
   - Includes the latest updates from `rohingya-film-school-updated.zip` (expanded profile for Co-founder & Media and Communications Lead **Mohammed Zonaid**, updated portraits for **Mohammed Faruque** and **Saidul Huq**, five founding objectives, 13-item searchable resource archive, and vibrant teal/saffron/coral styling).

---

## Deploying to Vercel

### Option 1: One-Command CLI Deployment
From inside the project directory, run:

```bash
npx vercel
```
To deploy directly to production:
```bash
npx vercel --prod
```

### Option 2: GitHub / Git Integration (Recommended)
1. Push this folder to a GitHub, GitLab, or Bitbucket repository.
2. Go to [vercel.com/new](https://vercel.com/new) and import the repository.
3. Vercel will automatically detect **Next.js** (`vercel.json` is pre-configured).
4. (Optional) Configure the following Environment Variables in your Vercel Project Settings:
   - `ADMIN_EMAILS`: Comma-separated list of emails allowed to edit content in `/admin` (defaults to `faruquebrr@gmail.com,mohammedzonaid7@gmail.com`).
   - `ADMIN_PASSWORD`: Optional passcode required when signing in at `/admin`.
   - `ADMIN_SECRET`: Random secret string used to sign admin session cookies.
5. Click **Deploy**.
